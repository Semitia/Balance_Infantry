#ifndef __CTRL_H__
#define __CTRL_H__

/* my object lib */
#include "Dormily.h"

void keyInput(void);
void hardwareCheck(void);
#endif // __CTRL_H__