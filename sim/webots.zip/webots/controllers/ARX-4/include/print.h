/*
 * @Author: your name
 * @Date: 2021-07-08 20:16:54
 * @LastEditTime: 2021-07-20 14:03:58
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \controllers\2_wheels_robot_controller\include\print.h
 */

#ifndef PRINT_H
#define PRINT_H

#define WB_USING_C_API
#include "types.h"
#include "arx.h"
#include "display.h"

#ifdef __cplusplus
extern "C" {
#endif

//double *variable;




#ifdef __cplusplus
}
#endif

#endif /* PRINT_H */