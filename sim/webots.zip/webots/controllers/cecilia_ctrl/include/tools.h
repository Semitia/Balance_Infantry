#ifndef __TOOLS_H__
#define __TOOLS_H__

#define limit(x, min, max) (x < min ? min : (x > max ? max : x))

#endif // __TOOLS_H__