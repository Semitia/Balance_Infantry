#ifndef __CTRL_H__
#define __CTRL_H__

/* my object lib */
#include "./include/cecilia.h"

void keyInput(void);

#endif // __CTRL_H__